﻿namespace AdvancedRoutingDemo.Dashboard
{
    public class admin
    {
    }
}
