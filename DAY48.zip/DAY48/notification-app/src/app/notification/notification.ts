import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.html',
  styleUrls: ['./notification.css']
})
export class NotificationComponent implements OnInit {
  @Input() message = '';
  @Input() type: 'success' | 'error' | 'warning' | 'info' = 'info';
  @Input() autoDismiss = true;
  @Input() dismissTime = 3000;
  @Output() closed = new EventEmitter<void>();

  visible = true;

  icons: Record<string, string> = {
    success: '✔️',
    error: '❌',
    warning: '⚠️',
    info: 'ℹ️'
  };

  ngOnInit() {
    if (this.autoDismiss) {
      setTimeout(() => this.closeNotification(), this.dismissTime);
    }
  }

  closeNotification() {
    this.visible = false;
    setTimeout(() => this.closed.emit(), 500);
  }
}
