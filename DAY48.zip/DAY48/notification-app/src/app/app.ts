export class AppComponent {
  notifVisible = false;
  notifMessage = '';
  notifType: 'success' | 'error' | 'warning' | 'info' = 'info';

  showNotification(msg: string, type: any) {
    this.notifMessage = msg;
    this.notifType = type;
    this.notifVisible = true;
  }
}
