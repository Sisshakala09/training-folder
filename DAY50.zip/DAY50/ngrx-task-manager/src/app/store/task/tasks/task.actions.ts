import { createAction, props } from '@ngrx/store';
import { Task } from './task.model';

// load (rehydrate)
export const loadTasksFromStorage = createAction('[Task] Load From Storage');
export const loadTasksSuccess = createAction('[Task] Load Success', props<{ tasks: Task[] }>());

// CRUD
export const addTask = createAction('[Task] Add', props<{ task: Task }>());
export const addTaskSuccess = createAction('[Task] Add Success', props<{ task: Task }>());
export const updateTask = createAction('[Task] Update', props<{ task: Task }>());
export const deleteTask = createAction('[Task] Delete', props<{ id: string }>());
