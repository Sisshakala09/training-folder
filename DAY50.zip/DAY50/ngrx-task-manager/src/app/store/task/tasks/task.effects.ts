import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import * as TaskActions from './task.actions';
import { tap, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { Task } from './task.model';

const STORAGE_KEY = 'ngrx_tasks_v1';

@Injectable()
export class TaskEffects {
  constructor(private actions$: Actions) {}

  // Persist tasks to localStorage whenever mutate actions occur:
  persistTasks$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(TaskActions.addTask, TaskActions.updateTask, TaskActions.deleteTask, TaskActions.addTaskSuccess),
        tap((action) => {
          // read current tasks from localStorage or from store? Simpler: update incrementally
          // Better approach is to persist after reducer runs via meta-reducer or via subscribing to store in an effect.
          // For clarity we'll rehydrate from localStorage and overwrite with new state saved by an effect subscriber in app.module.
        })
      ),
    { dispatch: false }
  );

  // Simple rehydrate effect: when loadTasksFromStorage dispatched, read from localStorage and emit loadTasksSuccess
  loadFromStorage$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TaskActions.loadTasksFromStorage),
      map(() => {
        try {
          const raw = localStorage.getItem(STORAGE_KEY);
          const tasks: Task[] = raw ? JSON.parse(raw) : [];
          return TaskActions.loadTasksSuccess({ tasks });
        } catch {
          return TaskActions.loadTasksSuccess({ tasks: [] });
        }
      })
    )
  );

  // We also create a generic effect that listens to all task state changes and writes the whole task list into localStorage.
  // Because effects don't have direct access to the store in this file, we'll implement a small pattern in app.module.ts that
  // subscribes to store and saves to localStorage (see app.module section).
}
