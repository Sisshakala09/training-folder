export interface Task {
  id: string;               // use string id (Date.now or UUID)
  title: string;
  description?: string;
  completed: boolean;
}
