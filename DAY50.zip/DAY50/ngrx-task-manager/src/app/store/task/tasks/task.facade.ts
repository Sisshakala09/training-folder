import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import * as TaskSelectors from './task.selectors';
import * as TaskActions from './task.actions';
import { Observable } from 'rxjs';
import { Task } from './task.model';

@Injectable({ providedIn: 'root' })
export class TaskFacade {
  tasks$: Observable<Task[]> = this.store.select(TaskSelectors.selectAllTasks);

  constructor(private store: Store) {}

  loadFromStorage() {
    this.store.dispatch(TaskActions.loadTasksFromStorage());
  }

  addTask(task: Task) {
    // Optimistic: dispatch success directly (no API)
    this.store.dispatch(TaskActions.addTaskSuccess({ task }));
  }

  updateTask(task: Task) {
    this.store.dispatch(TaskActions.updateTask({ task }));
  }

  deleteTask(id: string) {
    this.store.dispatch(TaskActions.deleteTask({ id }));
  }
}
