import { createFeatureSelector, createSelector } from '@ngrx/store';
import { TaskState, taskFeatureKey } from './task.reducer';

export const selectTaskState = createFeatureSelector<TaskState>(taskFeatureKey);

export const selectAllTasks = createSelector(selectTaskState, state => state.tasks);
export const selectCompletedTasks = createSelector(selectAllTasks, tasks => tasks.filter(t => t.completed));
export const selectPendingTasks = createSelector(selectAllTasks, tasks => tasks.filter(t => !t.completed));
