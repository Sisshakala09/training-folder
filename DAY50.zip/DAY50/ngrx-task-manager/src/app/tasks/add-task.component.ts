import { Component } from '@angular/core';
import { TaskFacade } from '../store/task/task.facade';
import { Task } from '../store/task/task.model';

@Component({
  selector: 'app-add-task',
  template: `
    <div class="add-form">
      <input [(ngModel)]="title" placeholder="Title" />
      <input [(ngModel)]="description" placeholder="Description" />
      <button (click)="add()">Add Task</button>
    </div>
  `,
  styles: [`.add-form { display:flex; gap:8px; margin-bottom:12px } input { padding:6px }`]
})
export class AddTaskComponent {
  title = '';
  description = '';
  constructor(private facade: TaskFacade) {}
  add() {
    const trimmed = this.title.trim();
    if (!trimmed) return;
    const newTask: Task = { id: Date.now().toString(), title: trimmed, description: this.description.trim(), completed: false };
    this.facade.addTask(newTask);
    this.title = ''; this.description = '';
  }
}
