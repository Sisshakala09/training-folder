import { Component, OnInit } from '@angular/core';
import { TaskFacade } from '../store/task/task.facade';
import { Observable } from 'rxjs';
import { Task } from '../store/task/task.model';

@Component({
  selector: 'app-task-list',
  template: `
    <div>
      <h2>Tasks</h2>
      <app-add-task></app-add-task>

      <ul>
        <li *ngFor="let t of tasks$ | async">
          <span [style.textDecoration]="t.completed ? 'line-through' : 'none'">{{ t.title }}</span>
          <button (click)="toggle(t)">{{ t.completed ? 'Undo' : 'Complete' }}</button>
        </li>
      </ul>
    </div>
  `
})
export class TaskListComponent implements OnInit {
  tasks$!: Observable<Task[]>;
  constructor(private facade: TaskFacade) {}
  ngOnInit() {
    this.tasks$ = this.facade.tasks$;
    this.facade.loadFromStorage(); // rehydrate on startup
  }
  toggle(t: Task) {
    this.facade.updateTask({ ...t, completed: !t.completed });
  }
}
