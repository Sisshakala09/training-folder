import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { StoreModule, ActionReducer, MetaReducer } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { AppComponent } from './app.component';
import { taskReducer, taskFeatureKey } from './store/task/task.reducer';
import { TaskEffects } from './store/task/task.effects';
import { FormsModule } from '@angular/forms';
import { TaskListComponent } from './tasks/task-list.component';
import { AddTaskComponent } from './tasks/add-task.component';
import { environment } from '../environments/environment';

@NgModule({
  declarations: [AppComponent, TaskListComponent, AddTaskComponent],
  imports: [
    BrowserModule,
    FormsModule,
    StoreModule.forRoot({}, {}),
    StoreModule.forFeature(taskFeatureKey, taskReducer),
    EffectsModule.forRoot([TaskEffects]),
    StoreDevtoolsModule.instrument({ maxAge: 25, logOnly: environment.production }),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor(private store: Store) {
    // Subscribe to task state and persist to localStorage on changes
    const STORAGE_KEY = 'ngrx_tasks_v1';
    import('@ngrx/store').then(({ select }) => {
      // simpler: use store.select to subscribe
    });

    // plain subscribe (no strong typing here for brevity)
    (this.store as any).select((state: any) => state[taskFeatureKey]?.tasks).subscribe((tasks: any[]) => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks ?? []));
      } catch (e) {
        // ignore storage errors
      }
    });
  }
}
