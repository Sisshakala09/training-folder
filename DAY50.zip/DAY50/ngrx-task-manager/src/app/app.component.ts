import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<div style="padding:12px"><app-task-list></app-task-list></div>`
})
export class AppComponent {}
