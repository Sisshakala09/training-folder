# Git Project Management Script

## 📌 Description
This script automates the process of creating and managing a Git repository for a project.  
It covers repository initialization, branching, committing, pushing, and merging.  

## 🚀 Usage

1. Edit variables inside the script:
   - `PROJECT_DIR` → Directory name for your project
   - `REMOTE_URL` → Remote Git repository URL
   - `NEW_BRANCH` → Name of the feature branch
   - `FILE_TO_EDIT` → File to modify (default: README.md)
   - `COMMIT_MESSAGE` → Commit message

2. Make the script executable:
   ```bash
   chmod +x git_project_manage.sh
   ```

3. Run the script:
   ```bash
   ./git_project_manage.sh
   ```

## ✅ Features
- Create a new Git repository with an initial commit  
- Add a remote and push code  
- Pull latest changes from remote  
- Modify files and commit changes  
- Create and push a feature branch  
- Merge branch into main (simulate merge request)  
