#!/bin/bash

# Exit immediately on error
set -e

# Variables (edit these as needed)
PROJECT_DIR="my_project"
REMOTE_URL="https://github.com/example/my_project.git"
NEW_BRANCH="feature-branch"
FILE_TO_EDIT="README.md"
COMMIT_MESSAGE="Update project code"

# 1. Create a new Git repository with an initial commit
mkdir "$PROJECT_DIR"
cd "$PROJECT_DIR" || exit
git init
echo "# My Project" > "$FILE_TO_EDIT"
git add "$FILE_TO_EDIT"
git commit -m "Initial commit"

# 2. Add a remote repository URL and push the code to the remote repository
git remote add origin "$REMOTE_URL"
git branch -M main
git push -u origin main

# 3. Update the code by pulling the latest changes from the remote repository
git pull origin main

# 4. Change the code and perform commit
echo "Some project update." >> "$FILE_TO_EDIT"
git add "$FILE_TO_EDIT"
git commit -m "$COMMIT_MESSAGE"
git push origin main

# 5. Create a separate branch and push changes to new branch
git checkout -b "$NEW_BRANCH"
echo "Feature branch changes." >> "$FILE_TO_EDIT"
git add "$FILE_TO_EDIT"
git commit -m "Add feature branch changes"
git push -u origin "$NEW_BRANCH"

# 6. Create a merge request and merge the branches
# NOTE: Merge request (Pull Request) usually needs to be created manually on GitHub/GitLab UI.
#       Here we simulate by merging locally and pushing to main.
git checkout main
git merge "$NEW_BRANCH"
git push origin main

echo "✅ Git repository setup and workflow completed!"
