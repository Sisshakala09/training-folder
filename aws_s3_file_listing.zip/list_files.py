import boto3
import argparse
from botocore.exceptions import NoCredentialsError, ClientError

def list_files(bucket_name, prefix=""):
    s3 = boto3.client("s3")
    try:
        response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        if "Contents" in response:
            print(f"✅ Files in bucket '{bucket_name}':")
            for obj in response["Contents"]:
                print(f"- {obj['Key']}")
        else:
            print(f"⚠️ No files found in bucket '{bucket_name}' with prefix '{prefix}'.")

    except NoCredentialsError:
        print("❌ AWS credentials not found. Configure them using 'aws configure'.")
    except ClientError as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AWS S3 File Listing Tool")
    parser.add_argument("bucket", help="S3 bucket name")
    parser.add_argument("--prefix", default="", help="Optional prefix to filter files")
    args = parser.parse_args()

    list_files(args.bucket, args.prefix)
