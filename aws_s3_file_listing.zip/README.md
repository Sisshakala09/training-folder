# AWS S3 File Listing Tool

## 📌 Description
A simple command-line tool to list files in an AWS S3 bucket.

---

## ⚙️ Requirements
- Python 3.7+
- boto3 (`pip install boto3`)
- AWS credentials configured (`aws configure`)

---

## 🚀 Installation & Usage

1. Clone or extract the project.
2. Install dependencies:
   ```bash
   pip install boto3
   ```
3. Configure AWS credentials if not already done:
   ```bash
   aws configure
   ```
4. Run the tool:
   ```bash
   python list_files.py <bucket_name> --prefix <optional_prefix>
   ```

Example:
```bash
python list_files.py my-s3-bucket --prefix documents/
```

---

## ✅ Sample Run
```
$ python list_files.py my-s3-bucket --prefix documents/
✅ Files in bucket 'my-s3-bucket':
- documents/report.pdf
- documents/data.csv
- documents/image.png
```

---

## 🔒 Notes
- Ensure your IAM user/role has `s3:ListBucket` permission.
- You can use the `--prefix` option to filter files by folder/path prefix.
