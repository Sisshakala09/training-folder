import { Component, OnInit } from '@angular/core';
//import { TaskService } from '../task.service';
import { TaskService } from '../Task Service/task.service';
//import { Task } from '../task.model';
import { Task } from '../model/task.model';

@Component({
  selector: 'app-task-list',
  standalone:true,
  templateUrl: './task-list.html'
})
export class TaskListComponent implements OnInit {
  tasks: Task[] = [];
  error: string | null = null;
  newTitle = '';

  constructor(private taskSvc: TaskService) {}

  ngOnInit() {
    this.load();
  }

  load() {
    this.error = null;
    this.taskSvc.getTasks().subscribe({
      next: data => (this.tasks = data),
      error: err => (this.error = err.message)
    });
  }

  addTask() {
    if (!this.newTitle.trim()) return;
    this.taskSvc.addTask(this.newTitle).subscribe(task => {
      this.tasks.unshift(task);
      this.newTitle = '';
    });
  }

  toggle(task: Task) {
    task.completed = !task.completed;
    this.taskSvc.updateTask(task).subscribe();
  }

  completeAll() {
    this.tasks.forEach(task => (task.completed = true));
  }
}
