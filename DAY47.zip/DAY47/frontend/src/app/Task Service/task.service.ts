import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
//import { Task } from './task.model';
import { Task } from '../model/task.model';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class TaskService {
  apiUrl = 'http://localhost:3000/tasks';

  constructor(private http: HttpClient) {}

  getTasks(): Observable<Task[]> {
    return this.http.get<Task[]>(this.apiUrl);
  }
  addTask(title: string): Observable<Task> {
    return this.http.post<Task>(this.apiUrl, { title });
  }
  updateTask(task: Task): Observable<Task> {
    return this.http.put<Task>(`${this.apiUrl}/${task.id}`, task);
  }
}
