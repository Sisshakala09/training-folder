// src/app/app.module.ts
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // required for Material animations
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; // <-- for [(ngModel)]
// Angular Material modules
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

import { App } from './app';
import { TaskListComponent } from './task-list/task-list';

@NgModule({
  declarations: [
    App,
    TaskListComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule, // <- Material needs this (or provideAnimations() for standalone)
    HttpClientModule,
    FormsModule,            // <- for ngModel
    // Material modules:
    MatCardModule,
    MatListModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule
  ],
  providers: [],
  bootstrap: [App]
})
export class AppModule { }
