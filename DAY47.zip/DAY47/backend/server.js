const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());           // Enable cross-origin requests
app.use(express.json());   // Parse JSON request bodies

app.get('/', (req, res) => {
  res.send('Task Management API is running');
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
