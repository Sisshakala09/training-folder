import boto3
import argparse
import os
from botocore.exceptions import NoCredentialsError, ClientError

def download_file(bucket_name, key, output_dir):
    s3 = boto3.client("s3")
    try:
        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)

        # Get filename from key
        file_name = os.path.basename(key)
        output_path = os.path.join(output_dir, file_name)

        # Check if object exists
        s3.head_object(Bucket=bucket_name, Key=key)

        # Download file
        s3.download_file(bucket_name, key, output_path)
        print(f"✅ File downloaded successfully: {output_path}")

    except NoCredentialsError:
        print("❌ AWS credentials not found. Configure them using 'aws configure'.")
    except ClientError as e:
        if e.response['Error']['Code'] == "404":
            print("❌ File not found in bucket.")
        else:
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AWS S3 File Downloader")
    parser.add_argument("bucket", help="S3 bucket name")
    parser.add_argument("key", help="S3 object key (file path)")
    parser.add_argument("--output", default="downloads", help="Directory to save downloaded file")
    args = parser.parse_args()

    download_file(args.bucket, args.key, args.output)
