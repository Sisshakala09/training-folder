# AWS S3 File Downloader

## 📌 Description
A simple command-line tool to download files from an AWS S3 bucket by specifying the bucket name and object key.

---

## ⚙️ Requirements
- Python 3.7+
- boto3 (`pip install boto3`)
- AWS credentials configured (`aws configure`)

---

## 🚀 Installation & Usage

1. Clone or extract the project.
2. Install dependencies:
   ```bash
   pip install boto3
   ```
3. Configure AWS credentials if not already done:
   ```bash
   aws configure
   ```
4. Run the tool:
   ```bash
   python downloader.py <bucket_name> <file_key> --output <directory>
   ```

Example:
```bash
python downloader.py my-s3-bucket documents/report.pdf --output downloads
```

---

## ✅ Sample Run
```
$ python downloader.py my-s3-bucket documents/report.pdf --output downloads
✅ File downloaded successfully: downloads/report.pdf
```

---

## 🔒 Notes
- Ensure your IAM user/role has `s3:GetObject` permission.
- The tool checks if the file exists before downloading.
