﻿public interface IReportService
{
    void GenerateAndSaveReport();
}
