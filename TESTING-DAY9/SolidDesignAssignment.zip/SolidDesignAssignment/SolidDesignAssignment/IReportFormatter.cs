﻿public interface IReportFormatter
{
    string Format(string content);
}
