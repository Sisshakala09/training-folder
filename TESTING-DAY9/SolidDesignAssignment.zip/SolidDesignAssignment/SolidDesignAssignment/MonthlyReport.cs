﻿public class MonthlyReport : Report
{
    public override string GetContent()
    {
        return "Monthly Report Content";
    }
}
