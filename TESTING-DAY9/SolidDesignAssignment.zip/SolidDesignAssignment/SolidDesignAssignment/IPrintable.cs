﻿public interface IPrintable
{
    void Print();
}
