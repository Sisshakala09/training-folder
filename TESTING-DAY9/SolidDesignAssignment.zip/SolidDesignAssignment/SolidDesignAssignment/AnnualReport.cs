﻿public class AnnualReport : Report
{
    public override string GetContent()
    {
        return "Annual Report Content";
    }
}
