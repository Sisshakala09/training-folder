# AWS S3 Image Uploader

## 📌 Description
A simple command-line tool to upload images to an AWS S3 bucket and generate public URLs.

---

## ⚙️ Requirements
- Python 3.7+
- boto3 (`pip install boto3`)
- AWS credentials configured (`aws configure`)

---

## 🚀 Installation & Usage

1. Clone or extract the project.
2. Install dependencies:
   ```bash
   pip install boto3
   ```
3. Configure AWS credentials if not already done:
   ```bash
   aws configure
   ```
4. Run the tool:
   ```bash
   python upload_image.py <bucket_name> <file_path>
   ```

Example:
```bash
python upload_image.py my-s3-bucket ./photo.jpg
```

---

## ✅ Sample Run
```
$ python upload_image.py my-s3-bucket ./photo.jpg
✅ Upload successful!
📂 File Key: uploads/550e8400-e29b-41d4-a716-446655440000_photo.jpg
🌐 Public URL: https://my-s3-bucket.s3.amazonaws.com/uploads/550e8400-e29b-41d4-a716-446655440000_photo.jpg
```

---

## 🔒 Notes
- Ensure your IAM user/role has `s3:PutObject` and `s3:PutObjectAcl` permissions.
- Uploaded images are made publicly accessible using `public-read` ACL.
- File keys are prefixed with `uploads/` and include a UUID for uniqueness.
