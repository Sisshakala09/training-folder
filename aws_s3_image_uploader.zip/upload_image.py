import boto3
import argparse
import os
import uuid
from botocore.exceptions import NoCredentialsError, ClientError

def upload_image(bucket_name, file_path):
    s3 = boto3.client("s3")
    try:
        if not os.path.isfile(file_path):
            print("❌ The specified file does not exist.")
            return
        
        # Generate unique key (UUID + original filename)
        file_name = os.path.basename(file_path)
        unique_key = f"uploads/{uuid.uuid4()}_{file_name}"
        
        # Upload file with public-read ACL
        s3.upload_file(file_path, bucket_name, unique_key, ExtraArgs={'ACL': 'public-read'})
        
        # Construct public URL (assuming bucket is in us-east-1; region can vary)
        url = f"https://{bucket_name}.s3.amazonaws.com/{unique_key}"
        print(f"✅ Upload successful!")
        print(f"📂 File Key: {unique_key}")
        print(f"🌐 Public URL: {url}")

    except NoCredentialsError:
        print("❌ AWS credentials not found. Configure them using 'aws configure'.")
    except ClientError as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AWS S3 Image Uploader")
    parser.add_argument("bucket", help="S3 bucket name")
    parser.add_argument("file", help="Path to the image file to upload")
    args = parser.parse_args()

    upload_image(args.bucket, args.file)
