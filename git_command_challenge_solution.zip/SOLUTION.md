# Git Command Challenge Solution

## Step-by-Step Git Commands

```bash
# 1. Clone the repository
git clone <repository-url>
cd <repository-folder>

# 2. Create and switch to new branch "feature/add-username"
git checkout -b feature/add-username

# 3. Create a new file "username.txt" and add username
echo "your-username" > username.txt

# 4. Stage the changes
git add username.txt

# 5. Commit the changes
git commit -m "Add username file"

# 6. Push the branch to remote
git push origin feature/add-username

# 7. Switch back to main branch
git checkout main

# 8. Create and switch to new branch "feature/update-readme"
git checkout -b feature/update-readme

# 9. Update README.md
echo "This repository is for Git Command Challenge" >> README.md

# 10. Stage the changes
git add README.md

# 11. Commit the changes
git commit -m "Update README"

# 12. Push the branch to remote
git push origin feature/update-readme

# 13. Switch back to main branch
git checkout main

# 14. Merge feature/update-readme into main
git merge feature/update-readme

# 15. Push merged changes to remote
git push origin main
```
