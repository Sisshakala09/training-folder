import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Subject, of, throwError } from 'rxjs';
import { catchError, startWith, switchMap, tap } from 'rxjs/operators';
import { Task } from '../models/task';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private tasksUrl = 'http://localhost:3000/api/tasks';
  private refresh$ = new Subject<void>();
  private errorSubject = new BehaviorSubject<string | null>(null);
  error$ = this.errorSubject.asObservable();

  // tasks$ is an observable stream that reloads whenever refresh$.next() is called
  tasks$ = this.refresh$.pipe(
    startWith(void 0),
    switchMap(() =>
      this.http.get<Task[]>(this.tasksUrl).pipe(
        catchError(err => {
          this.errorSubject.next('Could not load tasks. Is the backend running?');
          return of([] as Task[]);
        })
      )
    )
  );

  constructor(private http: HttpClient) {}

  addTask(payload: { title: string; description?: string }) {
    return this.http.post<Task>(this.tasksUrl, payload).pipe(
      tap(() => { this.errorSubject.next(null); this.refresh$.next(); }),
      catchError(err => {
        this.errorSubject.next('Failed to add task.');
        return throwError(() => err);
      })
    );
  }

  deleteTask(id: number) {
    return this.http.delete<void>(`${this.tasksUrl}/${id}`).pipe(
      tap(() => { this.errorSubject.next(null); this.refresh$.next(); }),
      catchError(err => {
        this.errorSubject.next('Failed to delete task.');
        return throwError(() => err);
      })
    );
  }

  updateTask(id: number, changes: Partial<Task>) {
    return this.http.put<Task>(`${this.tasksUrl}/${id}`, changes).pipe(
      tap(() => { this.errorSubject.next(null); this.refresh$.next(); }),
      catchError(err => {
        this.errorSubject.next('Failed to update task.');
        return throwError(() => err);
      })
    );
  }
}
