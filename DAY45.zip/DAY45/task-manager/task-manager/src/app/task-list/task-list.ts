// import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { Task } from '../models/task';
// import { TaskService } from '../services/task.service';
// import { Observable } from 'rxjs';

// @Component({
//   selector: 'app-task-list',
//   templateUrl: './task-list.html',
//   styleUrls: ['./task-list.css']
// })
// export class TaskListComponent implements OnInit {
//   tasks$: Observable<Task[]>;
//   error$ = this.taskService.error$;
//   form: FormGroup;

//   constructor(private fb: FormBuilder, private taskService: TaskService) {
//     this.tasks$ = this.taskService.tasks$;
//     this.form = this.fb.group({
//       title: ['', Validators.required],
//       description: ['']
//     });
//   }

//   ngOnInit(): void { }

//   addTask() {
//     if (this.form.invalid) return;
//     const value = this.form.value;
//     this.taskService.addTask({ title: value.title, description: value.description })
//       .subscribe({
//         next: () => this.form.reset(),
//         error: (err) => console.error(err)
//       });
//   }

//   deleteTask(id: number) {
//     if (!confirm('Delete this task?')) return;
//     this.taskService.deleteTask(id).subscribe({
//       next: () => { /* refresh happens in service */ },
//       error: (err) => console.error(err)
//     });
//   }

//   toggleStatus(task: Task) {
//     const newStatus = task.status === 'pending' ? 'completed' : 'pending';
//     this.taskService.updateTask(task.id, { status: newStatus }).subscribe({
//       next: () => {},
//       error: (err) => console.error(err)
//     });
//   }
// }



import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TaskService } from '../services/task.service';
import { Task } from '../models/task';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.html',
  styleUrls: ['./task-list.css']
})
export class TaskListComponent implements OnInit {
  tasks$!: Observable<Task[]>;   // declare first
  error$ = this.taskService.error$;
  form: FormGroup;

  constructor(private fb: FormBuilder, private taskService: TaskService) {
    this.form = this.fb.group({
      title: ['', Validators.required],
      description: ['']
    });
  }

  ngOnInit(): void {
    this.tasks$ = this.taskService.tasks$;  // ✅ safe to assign here
  }

  addTask() { /* same as before */ }
  deleteTask(id: number) { /* same as before */ }
  toggleStatus(task: Task) { /* same as before */ }
}
