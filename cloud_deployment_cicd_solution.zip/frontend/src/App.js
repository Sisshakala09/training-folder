// src/App.js
import React from "react";

function App() {
  return (
    <div>
      <h1>Contact Management System</h1>
      <p>Frontend deployed successfully 🚀</p>
    </div>
  );
}

export default App;
