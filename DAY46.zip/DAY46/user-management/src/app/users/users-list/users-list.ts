import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../user.model';
import { UserService } from '../user.service';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.html',
  styleUrls: ['./users-list.css']
})
export class UsersListComponent implements OnInit {
  users$!: Observable<User[]>;
  error: string | null = null;

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.users$ = this.userService.getUsers();
  }
}
