export interface User {
  id: number;
  name: string;
  email: string;
  // add other fields if needed
}
