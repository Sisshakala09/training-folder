# Git Repository Management Script

## 📌 Description
This script automates common Git repository management tasks including cloning, branching, committing, pushing, merging, and pulling changes.

## 🚀 Usage

1. Edit the variables inside the script:
   - `REPO_URL` → URL of your Git repository
   - `NEW_BRANCH` → Name of the new branch
   - `FILE_TO_EDIT` → File to modify (default: README.md)
   - `COMMIT_MESSAGE` → Commit message

2. Make the script executable:
   ```bash
   chmod +x git_repo_manage.sh
   ```

3. Run the script:
   ```bash
   ./git_repo_manage.sh
   ```

## ✅ Features
- Clone repository
- List branches
- Create and switch branches
- Modify file and commit changes
- Push to remote
- Merge into main/master
- Pull latest changes
