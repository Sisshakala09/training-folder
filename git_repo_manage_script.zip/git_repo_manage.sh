#!/bin/bash

# Exit on error
set -e

# Variables (edit these as needed)
REPO_URL="https://github.com/example/repo.git"
NEW_BRANCH="feature-branch"
FILE_TO_EDIT="README.md"
COMMIT_MESSAGE="Update README with new changes"

# 1. Clone a Git repository from a remote URL
git clone "$REPO_URL"
cd repo || exit

# 2. List all branches in the repository
echo "📌 Listing branches:"
git branch -a

# 3. Create a new branch
git branch "$NEW_BRANCH"

# 4. Switch to a specific branch
git checkout "$NEW_BRANCH"

# 5. Make changes to a file in the repository
echo "This is an automated update." >> "$FILE_TO_EDIT"

# 6. Commit the changes with a custom commit message
git add "$FILE_TO_EDIT"
git commit -m "$COMMIT_MESSAGE"

# 7. Push the branch to the remote repository
git push origin "$NEW_BRANCH"

# 8. Merge the branch into the main branch (master/main)
git checkout main || git checkout master
git merge "$NEW_BRANCH"

# 9. Pull the latest changes from the remote repository
git pull origin main || git pull origin master

echo "✅ Git operations completed successfully!"
